#include<stdio.h>
int main()
{
	printf("400");
	return 0;
}