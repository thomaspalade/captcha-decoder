#include<stdio.h>
int main()
{
	printf("14");
	return 0;
}